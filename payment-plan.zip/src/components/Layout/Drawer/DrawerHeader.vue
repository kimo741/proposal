<template>
  <div class="dawer-header flex flex-center">
    <q-img src="LOGO (2).png" width="40%" />
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
@media (max-width: $breakpoint-xs-max) {
  .dawer-header {
    height: 15vh;
  }
}
@media (min-width: $breakpoint-sm-min) {
  .dawer-header {
    height: 15vh;
  }
}
</style>
