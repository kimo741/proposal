<template>
  <div>
    <div>
      <header-info @addNew="addNew"> Category </header-info>
    </div>
    <dynamic-table
      :show="show"
      :actions="actions"
      :data="getCats"
      :column="column"
      @sort="sort"
      @pagination="pagination"
      @search="search"
      @edit="edit"
      @deleteRow="confirmDelete"
    />
    <drower>
      <template #form-header>
        {{ formPageTtitel }}
        Categore
      </template>
      <template #form-content>
        <CategoryForm :row="rowToEdit" />
      </template>
    </drower>
  </div>
</template>
<script>
import { table } from "src/Mixins/DynamicTable";
import { email } from "src/Mixins/EmailVildate";
import DynamicTable from "src/components/Table/dynamic.vue";
import HeaderInfo from "src/components/UI/header-info";
import CategoryForm from "src/components/Category/category-form.vue";
import Drower from "src/components/UI/drower.vue";
export default {
  mixins: [table, email],
  components: {
    DynamicTable,
    HeaderInfo,
    Drower,
    CategoryForm,
  },
  data() {
    return {
      column: [
        {
          name: "label",
          label: "Name",
          align: "left",
          sort: true,
          search: true,
          isImage: true,
          search: true,
        },
        {
          name: "value",
          label: "Name",
          align: "left",
          sort: false,
          search: false,
        },
      ],
    };
  },
  computed: {
    getCats() {
      return this.$store.getters["Cat/cats"];
    },
  },
  methods: {
    async deleteRow(val) {
      // await this.$store
      //   .dispatch("Cat/deleteCat", val.id)
      //   .then(() => {
      //     this.$q.notify("Data Deleted successfully");
      //   })
      //   .catch((err) => {
      //     this.error(err);
      //   });
    },
    async getData() {
      this.handelUrl();
      this.LShow();
      await this.$store.dispatch("Cat/getCats", this.payload).then(() => {
        this.LHide();
      });
    },
  },
  created() {
    this.getData();
  },
};
</script>

<style></style>
