import { Cookies, Notify } from "quasar";
import { api } from "../boot/axios";

const prefix = "dashboard/category";

const state = {
  cats: [],
};

const mutations = {
  GET_VUEX(state, payload) {
    state.cats = payload;
  },
};

const actions = {
  async getVuex({ commit }, payload) {
    const { data } = await api.get(`category/show-table?${payload}`);
    commit("GET_VUEX", await data);
    return data;
  },
};

const getters = {
  cats: (state) => {
    return state.cats;
  },
};

export default {
  namespaced: true,
  getters,
  mutations,
  actions,
  state,
};
