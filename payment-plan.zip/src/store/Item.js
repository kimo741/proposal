import { Cookies, Notify } from "quasar";
import { api } from "../boot/axios";

const prefix = "dashboard/category";

const state = {
  item: [],
};

const mutations = {
  GET_ITEMS(state, payload) {
    state.item = payload;
  },
};

const actions = {
  async getItems({ commit }, payload) {
    const { data } = await api.get(`category/show-table?${payload}`);
    commit("GET_VUEX", await data);
    return data;
  },
};

const getters = {
  item: (state) => {
    return state.item;
  },
};

export default {
  namespaced: true,
  getters,
  mutations,
  actions,
  state,
};
