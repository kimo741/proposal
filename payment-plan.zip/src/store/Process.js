import { Cookies, Notify } from "quasar";
import { api } from "../boot/axios";

const prefix = "dashboard/category";

const state = {
  Process: [],
};

const mutations = {
  GET_PROCESS(state, payload) {
    state.Process = payload;
  },
};

const actions = {
  async getProcess({ commit }, payload) {
    const { data } = await api.get(`category/show-table?${payload}`);
    commit("GET_PROCESS", await data);
    return data;
  },
};

const getters = {
  Process: (state) => {
    return state.Process;
  },
};

export default {
  namespaced: true,
  getters,
  mutations,
  actions,
  state,
};
