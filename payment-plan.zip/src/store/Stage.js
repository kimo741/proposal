import { Cookies, Notify } from "quasar";
import { api } from "../boot/axios";

const prefix = "dashboard/category";

const state = {
  Stage: [],
};

const mutations = {
  GET_STAGE(state, payload) {
    state.Stage = payload;
  },
};

const actions = {
  async getStage({ commit }, payload) {
    const { data } = await api.get(`category/show-table?${payload}`);
    commit("GET_STAGE", await data);
    return data;
  },
};

const getters = {
  Stage: (state) => {
    return state.Stage;
  },
};

export default {
  namespaced: true,
  getters,
  mutations,
  actions,
  state,
};
